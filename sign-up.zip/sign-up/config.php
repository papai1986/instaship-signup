<?php
	$server = "127.0.0.1";
	$root = "u668174424_instaship";
	$pass = "instaShip712201";
	$db_name = "u668174424_instaship";

	$conn = mysqli_connect($server, $root, $pass, $db_name);

	if (!$conn) {
		// code...
		echo "Database Not Connected";
	}
?>