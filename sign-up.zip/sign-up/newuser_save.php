<?php
if($_SERVER['REQUEST_METHOD'] == "POST"){
    include("../connection/config.php");
    date_default_timezone_set('Asia/Kolkata');
	$date = date("Y-m-d H:i:s");
    $msg = "";
    $f_name = $_POST['first_name'];
    $s_name = $_POST['last_name'];
    $contact = $_POST['mobile_no'];
    $email = $_POST['email_id'];
    $password = $_POST['password'];
    $signature = $_POST['term_condition'];
    $hash_password = password_hash($password, PASSWORD_DEFAULT);
    
    // get User Ip address..
    function get_client_ip() {
        $ipaddress = '';
        if (getenv('HTTP_CLIENT_IP'))
            $ipaddress = getenv('HTTP_CLIENT_IP');
        else if(getenv('HTTP_X_FORWARDED_FOR'))
            $ipaddress = getenv('HTTP_X_FORWARDED_FOR');
        else if(getenv('HTTP_X_FORWARDED'))
            $ipaddress = getenv('HTTP_X_FORWARDED');
        else if(getenv('HTTP_FORWARDED_FOR'))
            $ipaddress = getenv('HTTP_FORWARDED_FOR');
        else if(getenv('HTTP_FORWARDED'))
           $ipaddress = getenv('HTTP_FORWARDED');
        else if(getenv('REMOTE_ADDR'))
            $ipaddress = getenv('REMOTE_ADDR');
        else
            $ipaddress = 'UNKNOWN';
            return $ipaddress;
    }
            
    $sys_ip = get_client_ip();
    //check mobile no validity...
    $val_sql = "SELECT * FROM new_user_otp WHERE expired = 1 AND mobile = '".$contact."' AND NOW() <= DATE_ADD(otp_time, INTERVAL 15 MINUTE)";
    $val_query = $conn->query($val_sql);
    if($val_query->num_rows > 0){
        // check duplicate user ..
        $chk_sql = "SELECT * FROM user_details WHERE mobile_no = '".$contact."' OR email_id = '".$email."'";
        $chk_query = $conn->query($chk_sql);
        if($chk_query->num_rows == 0){
            $sql = "INSERT INTO user_details (Status, user_name, mobile_no, email_id, password, first_name, second_name, user_sign, date_stamp) VALUES ('Initiate', '".$contact."', '".$contact."', '".$email."', '".$hash_password."','".$f_name."', '".$s_name."', '".$signature."', '".$date."')";
            $ip_sql = "INSERT INTO user_auth_root (user_name, ipv6_address, user_session_time) VALUES ('".$contact."', '".$sys_ip."', '".$date."')";
            if($conn->query($sql) && $conn->query($ip_sql)){
                $msg = json_encode(array("Status"=> 1, "massage"=>"WelCome ".$f_name." ".$f_name."\nThank You for Choosing Us"));
            }else{
                $msg = json_encode(array("Status"=>2, "massage"=> "Try After Sometime"));
            }
            //echo "First Name: ".$f_name.", Last Name: ".$s_name.", Contact No: ".$contact." Email: ".$email." Password: ".$hash_password.", User Ip".$sys_ip.", Date: ".$date;
        }else{
            $msg = json_encode(array("Status"=>3, "massage"=> "Existing User Not Allowed"));
        }
    }else{
        $msg = json_encode(array("Status"=>4, "massage"=> "Please Verify Your Mobile No"));
    }
    echo $msg;
}else{
    echo "Posting Failed";
}
?>