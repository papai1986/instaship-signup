<?php
	if ($_SERVER['REQUEST_METHOD'] == "POST") {
		// code...
		include('config.php');
		date_default_timezone_set('Asia/Kolkata');
		$date = date("Y-m-d");
		$time = date("H:i:s");
		//$time = date("Y-m-d H:i:s");
		
		if (!empty($_POST['post_data'] == 1)) {
			// code...
			$otp = rand(100000, 999999);
			$msg = "Your one time password is ".$otp." for Sign Up in Instaship . Powered By Shopingcart Retail Service";
			$mobile = $_POST['mobile'];
			// Array data...
			$fields = array(
			    "sender_id" => "TXINSP",
			    "message" => $msg,
			    "template_id" => "1407165701220364695", // 1407165701220364695
			    "entity_id" => "1401695540000047169", // 1401695540000047169
			    "route" => "dlt_manual",
			    "numbers" => $mobile,
			);
			// initiate cURL request ...

			$curl = curl_init();

			curl_setopt_array($curl, array(
			  CURLOPT_URL => "https://www.fast2sms.com/dev/bulkV2",
			  CURLOPT_RETURNTRANSFER => true,
			  CURLOPT_ENCODING => "",
			  CURLOPT_MAXREDIRS => 10,
			  CURLOPT_TIMEOUT => 30,
			  CURLOPT_SSL_VERIFYHOST => 0,
			  CURLOPT_SSL_VERIFYPEER => 0,
			  CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
			  CURLOPT_CUSTOMREQUEST => "POST",
			  CURLOPT_POSTFIELDS => json_encode($fields),
			  CURLOPT_HTTPHEADER => array(
			    "authorization: q41fO5iZscUpX7J7tuhzJwNaQXkyFakhLNPHkgRsOuGrok2ZetBG1wYMKiP0",
			    "accept: */*",
			    "cache-control: no-cache",
			    "content-type: application/json"
			  ),
			));

			$response = curl_exec($curl);
			$err = curl_error($curl);

			curl_close($curl);
			$reponse_data = json_decode($response, true);
			$response_id = $reponse_data['request_id'];
			$return = $reponse_data['return'];
			if (!$err) {
				// code...
				if ($reponse_data['return'] == 1) {
				// code...
					$sql = "INSERT INTO new_user_otp (mobile, otp, sending_id, expired, created, otp_time) VALUES ('$mobile', '$otp', '$response_id', '0', '$date', '$time')";
					$query = $conn->query($sql);
					if ($query) {
						// code...
						echo json_encode(array("status"=> 100, "request_id"=> $response_id, "massage"=> "OTP Sent Successfully")) ;
					}else{
						echo json_encode(array("status"=> 101, "massage"=> "OTP Sending Failed"));
					}
				}else{
					echo json_encode(array("status"=> 102, "massage"=>"Check Your Mobile No"));
				}
			}else{
				echo json_encode(array("status"=> 103, "massage"=>"Please Try After Some Time"));
			}
		}
	}
?>