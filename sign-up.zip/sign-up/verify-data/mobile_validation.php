<?php
if($_SERVER["REQUEST_METHOD"] == "POST"){
    include('../../connection/config.php');
    $mobile = $_POST['mobile'];
    $sql = "SELECT * FROM user_details WHERE mobile_no = '".$mobile."'";
    $stmt = $conn->query($sql);
    if($stmt->num_rows == 0){
        echo json_encode(array("http_code"=> 201));
    }else{
        echo json_encode(array("http_code"=> 202));
    }
    
}
?>