<?php
if($_SERVER["REQUEST_METHOD"] == "POST"){
    include('../../connection/config.php');
    $email = $_POST['email'];
    $sql = "SELECT * FROM user_details WHERE email_id = '".$email."'";
    $stmt = $conn->query($sql);
    if($stmt->num_rows == 0){
        echo json_encode(array("http_code"=> 201));
    }else{
        echo json_encode(array("http_code"=> 202));
    }
}
?>