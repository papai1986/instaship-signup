<?php
	if ($_SERVER['REQUEST_METHOD'] == "POST") {
		// code...
		include('config.php');
		date_default_timezone_set('Asia/Kolkata');
		$date = date("Y-m-d H:i:s");
		$received_otp = $_POST['otp'];
		$request_id = $_POST['request'];
		//echo $received_otp."\n";
		$sql = "SELECT * FROM new_user_otp WHERE otp = '".$received_otp."' AND sending_id = '".$request_id."' AND expired = 0 AND NOW() <= DATE_ADD(otp_time, INTERVAL 5 MINUTE)";
		$query = $conn->query($sql);
		if ($query->num_rows == 1) {
			// code...
			$row = $query->fetch_array(MYSQLI_ASSOC);
			$update_sql = "UPDATE new_user_otp SET expired = 1 WHERE id='".$row['id']."'";
			if ($conn->query($update_sql)) {
				// code...
				echo json_encode(array("Status"=> 1, "massage"=> "Your Update Successfully"));
			}else{
				echo json_encode(array("Status"=> 2, "massage"=> "Please Try Again"));
			}
		}else{
			echo json_encode(array("Status"=> 2, "massage"=> "Your OTP is Expired"));
		}
	}
?>